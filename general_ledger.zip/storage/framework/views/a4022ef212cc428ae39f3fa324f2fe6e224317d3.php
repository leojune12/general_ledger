<?php $__env->startSection('content'); ?>
    <view-dashboard></view-dashboard>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\development\webFiles\projects\general_ledger\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>