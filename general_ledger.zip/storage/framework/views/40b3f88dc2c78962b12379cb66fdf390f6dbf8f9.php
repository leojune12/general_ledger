<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'General Ledger')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <style>
        body {
            font-family: Arial, Helvetica, sans-serif !important;
        }

        
        html { overflow-y: auto !important; }

        /* width */
        ::-webkit-scrollbar {
            width: 10px;
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background: #888;
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        button {
            outline: none !important;
        }

        a {
            text-decoration: none !important;
        }
    </style>

</head>
<body>
    <div id="app">
        
        <?php if(auth()->guard()->check()): ?>

        <v-app>
            <navigation-drawer></navigation-drawer>
            <app-bar></app-bar>
            <v-main>
                <?php echo $__env->yieldContent('content'); ?>
            </v-main>
            <miscellaneous></miscellaneous>
        </v-app>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>

        <?php endif; ?>

    </div>
</body>
</html>
<?php /**PATH D:\development\webFiles\projects\general_ledger\resources\views/layouts/app.blade.php ENDPATH**/ ?>