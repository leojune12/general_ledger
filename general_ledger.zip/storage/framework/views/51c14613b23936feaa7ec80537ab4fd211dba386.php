<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Login</title>
    
    

    

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

</head>

<style>
    body {
        font-family: Arial, Helvetica, sans-serif !important;
    }
</style>

<body style="background-color: #ECEFF1;">
    <div style="position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%)">
        <div class="card mx-auto" style="min-width: 300px; width: 320px;">
            <div class="card-header bg-white border-0">
                <h4 class="text-dark ">GENERAL LEDGER</h4>
                <h5><small>Welcome back, please login to your account.</small></h5>
            </div>
            <div class="card-body pb-1 pt-0">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <input
                        type="text"
                        class="form-control mb-3"
                        placeholder="Username"
                        name="email"
                        value="<?php echo e(old('email')); ?>"
                        autocomplete="off"
                        required
                    >

                    <input
                        type="password"
                        class="form-control mb-3"
                        placeholder="Password"
                        name="password"
                        autocomplete="current-password"
                        required
                        value="<?php echo e(old('password')); ?>"
                    >

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger mb-3">
                            <ul class="mb-0 pl-2">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                </form>
            </div>
            <div class="card-footer border-0 bg-white text-center pt-2">
                <small>A Program by Leo June Bedeo</small>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\development\webFiles\projects\general_ledger\resources\views/auth/login.blade.php ENDPATH**/ ?>