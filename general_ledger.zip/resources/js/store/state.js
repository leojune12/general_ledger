let state = {
    data: 'test data',

    drawer: null,

    drawerLinks: {
        dashboard: false,

        ledger: false,

        accountCodes: false,

        projectCodes: false,

    },

    snackbar: {
        value: false,
        text: '',
        color: ''
    },

    loadingDialog: false,


}

export default state
