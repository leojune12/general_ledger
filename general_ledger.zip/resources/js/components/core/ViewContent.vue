<template>

</template>

<script>
    export default {
        name: "ViewContent"
    }
</script>

<style scoped>

</style>
