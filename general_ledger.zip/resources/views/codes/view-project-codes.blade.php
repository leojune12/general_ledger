@extends('layouts.app')

@section('content')
    <view-project-codes></view-project-codes>
@endsection
