@extends('layouts.app')

@section('content')
    <view-account-codes></view-account-codes>
@endsection
