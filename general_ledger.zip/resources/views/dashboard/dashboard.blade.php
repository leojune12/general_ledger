@extends('layouts.app')

@section('content')
    <view-dashboard></view-dashboard>
@endsection
