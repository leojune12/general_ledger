@extends('layouts.app')

@section('content')
    <view-ledgers></view-ledgers>
@endsection
