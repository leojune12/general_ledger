<?php

namespace App\Models\Codes;

use Illuminate\Database\Eloquent\Model;

class ProjectCode extends Model
{
    protected $fillable = [
        'description'
    ];
}
