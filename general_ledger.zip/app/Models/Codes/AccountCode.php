<?php

namespace App\Models\Codes;

use Illuminate\Database\Eloquent\Model;

class AccountCode extends Model
{
    protected $fillable = [
        'description'
    ];
}
